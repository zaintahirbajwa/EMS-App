package com.example.event_management_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
