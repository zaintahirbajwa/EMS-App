import 'package:cloud_firestore/cloud_firestore.dart';

class EventModel {
  final String id;
  final String name;
  final String description;
  final DateTime date;
  final String location;
  final int totalTickets;
  final int ticketsSold;
  final String organizerName;
  final String organizerContact;
  final String category; // Event category
  final double ticketPrice; // Ticket price
  final String imageUrl; // Event image URL
  final String contactInfo; // Contact info for the event
  final String registrationLink; // Registration link for the event

  EventModel({
    required this.id,
    required this.name,
    required this.description,
    required this.date,
    required this.location,
    required this.totalTickets,
    required this.ticketsSold,
    required this.organizerName,
    required this.organizerContact,
    required this.category,
    required this.ticketPrice,
    required this.imageUrl,
    required this.contactInfo,
    required this.registrationLink,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'date': Timestamp.fromDate(date),
      'location': location,
      'totalTickets': totalTickets,
      'ticketsSold': ticketsSold,
      'organizerName': organizerName,
      'organizerContact': organizerContact,
      'category': category,
      'ticketPrice': ticketPrice,
      'imageUrl': imageUrl,
      'contactInfo': contactInfo,
      'registrationLink': registrationLink,
    };
  }

  factory EventModel.fromJson(Map<String, dynamic> json) {
    return EventModel(
      id: json['id'] ?? '', // Default to empty string if id is null
      name: json['name'] ?? '', // Default to empty string if name is null
      description: json['description'] ??
          '', // Default to empty string if description is null
      date: (json['date'] as Timestamp?)?.toDate() ??
          DateTime.now(), // Default to current date if date is null
      location:
          json['location'] ?? '', // Default to empty string if location is null
      totalTickets:
          json['totalTickets'] ?? 0, // Default to 0 if totalTickets is null
      ticketsSold:
          json['ticketsSold'] ?? 0, // Default to 0 if ticketsSold is null
      organizerName: json['organizerName'] ??
          '', // Default to empty string if organizerName is null
      organizerContact: json['organizerContact'] ??
          '', // Default to empty string if organizerContact is null
      category:
          json['category'] ?? '', // Default to empty string if category is null
      ticketPrice: (json['ticketPrice'] ?? 0.0)
          .toDouble(), // Default to 0.0 if ticketPrice is null
      imageUrl:
          json['imageUrl'] ?? '', // Default to empty string if imageUrl is null
      contactInfo: json['contactInfo'] ??
          '', // Default to empty string if contactInfo is null
      registrationLink: json['registrationLink'] ??
          '', // Default to empty string if registrationLink is null
    );
  }

  EventModel withUpdatedTicketsSold(int newTicketsSold) {
    return EventModel(
      id: id,
      name: name,
      description: description,
      date: date,
      location: location,
      totalTickets: totalTickets,
      ticketsSold: newTicketsSold,
      organizerName: organizerName,
      organizerContact: organizerContact,
      category: category,
      ticketPrice: ticketPrice,
      imageUrl: imageUrl,
      contactInfo: contactInfo,
      registrationLink: registrationLink,
    );
  }

  int get soldTickets => ticketsSold;

  int get ticketQuantity => totalTickets - ticketsSold;
}
