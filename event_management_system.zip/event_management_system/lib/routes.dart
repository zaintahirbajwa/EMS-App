import 'package:flutter/material.dart';
import 'package:event_management_system/utils/animations.dart';
import 'package:event_management_system/views/auth/login_screen.dart';
import 'package:event_management_system/views/admin/event_registration_screen.dart';
import 'package:event_management_system/views/admin/event_schedule_screen.dart';
import 'package:event_management_system/views/user/user_schedule_screen.dart';
import 'package:event_management_system/views/admin/ticketing_screen.dart';
import 'package:event_management_system/views/user/user_ticketing_screen.dart';
import 'package:event_management_system/views/common/chat_screen.dart';
import 'package:event_management_system/views/common/settings_screen.dart';

class Routes {
  // Route names
  static const String login = '/login';
  static const String eventRegistration = '/eventRegistration';
  static const String adminSchedule = '/adminSchedule';
  static const String userSchedule = '/userSchedule';
  static const String adminTicketing = '/adminTicketing';
  static const String userTicketing = '/userTicketing';
  static const String chat = '/chat';
  static const String settings = '/settings';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case login:
        return slideTransitionRightToLeft(LoginScreen());
      case eventRegistration:
        return bounceTransition(EventRegistrationScreen());
      case adminSchedule:
        return scaleTransition(EventScheduleScreen());
      case userSchedule:
        return slideTransitionBottomToTop(UserScheduleScreen());
      case adminTicketing:
        return rotateTransition(AdminTicketingScreen());
      case userTicketing:
        return fadeTransition(UserTicketingScreen());
      case chat:
        return flipTransition(ChatScreen());
      case Routes.settings: // Ensure consistent use of static route constants
        return zoomInTransition(SettingsScreen());
      default:
        // Handle unmatched routes
        return slideTransitionRightToLeft(LoginScreen());
    }
  }
}
