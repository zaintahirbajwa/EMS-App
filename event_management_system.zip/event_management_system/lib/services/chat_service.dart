import 'dart:convert';
import 'package:http/http.dart' as http;

class ChatService {
  // Your Gemini API key
  static const String _apiKey = 'AIzaSyBBitreHHFJymbHRuHe8Bs_989VpxrXa6o';
  static const String _apiUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateText'; // Gemini API URL

  // Method to send a message to the Gemini API and receive a response
  Future<String> sendMessage(String prompt) async {
    // Construct the body of the request
    final Map<String, dynamic> body = {
      'prompt': prompt,
      'max_tokens': 150, // Max tokens to return in the response
      'temperature': 0.7, // Controls the randomness of the response
    };

    try {
      // Send the POST request
      final response = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_apiKey', // Pass the API key in headers
        },
        body: json.encode(body),
      );

      // Log the response status and body for debugging
      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        return responseData['choices'][0]['text']
            .trim(); // Extract and return the response text
      } else {
        // If API returns an error, log it
        return 'Error: ${response.statusCode} - ${response.body}';
      }
    } catch (e) {
      // Catch any errors and return them
      return 'Error: $e';
    }
  }
}
