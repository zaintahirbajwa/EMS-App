import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:event_management_system/models/event_model.dart';

class EventService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Change the collection name here to 'availableEvents'
  CollectionReference get _eventsCollection =>
      _firestore.collection('availableEvents');

  Future<List<EventModel>> getEvents() async {
    try {
      QuerySnapshot querySnapshot = await _eventsCollection.get();
      return querySnapshot.docs.map((doc) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        data['id'] = doc.id;
        return EventModel.fromJson(data);
      }).toList();
    } catch (e) {
      print("Error retrieving events: $e");
      rethrow;
    }
  }

  Future<void> saveEvents(List<EventModel> events) async {
    try {
      QuerySnapshot snapshot = await _eventsCollection.get();
      for (var doc in snapshot.docs) {
        await doc.reference.delete();
      }

      for (var event in events) {
        await addEvent(event);
      }
    } catch (e) {
      print("Error saving events: $e");
      rethrow;
    }
  }

  Future<void> addEvent(EventModel event) async {
    try {
      // Log the event before adding it to Firestore
      print("Adding event: ${event.toJson()}");

      // Add event to 'availableEvents' collection
      DocumentReference docRef = await _eventsCollection.add(event.toJson());

      // Log the document reference after adding
      print("Event added with ID: ${docRef.id}");

      // Update the event document with its ID
      await docRef.update({'id': docRef.id});

      // Log the successful update
      print("Event updated with ID field successfully.");
    } catch (e) {
      print("Error adding event: $e");
      rethrow;
    }
  }

  Future<void> updateEvent(EventModel updatedEvent) async {
    try {
      QuerySnapshot eventDoc =
          await _eventsCollection.where('id', isEqualTo: updatedEvent.id).get();

      if (eventDoc.docs.isNotEmpty) {
        await eventDoc.docs.first.reference.update(updatedEvent.toJson());
      } else {
        print("No event found with ID: ${updatedEvent.id}");
      }
    } catch (e) {
      print("Error updating event: $e");
      rethrow;
    }
  }

  Future<void> deleteEvent(String eventId) async {
    try {
      QuerySnapshot eventDoc =
          await _eventsCollection.where('id', isEqualTo: eventId).get();

      if (eventDoc.docs.isNotEmpty) {
        await eventDoc.docs.first.reference.delete();
      } else {
        print("No event found with ID: $eventId");
      }
    } catch (e) {
      print("Error deleting event: $e");
      rethrow;
    }
  }
}
