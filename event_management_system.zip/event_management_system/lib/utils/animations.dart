import 'package:flutter/material.dart';

// Slide transition from right to left (common for page transitions)
Route<dynamic> slideTransitionRightToLeft(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var begin =
          const Offset(1.0, 0.0); // Starting position: right of the screen
      var end = Offset.zero; // Ending position: the screen itself
      var curve = Curves.easeInOut; // Animation curve
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);

      return SlideTransition(position: offsetAnimation, child: child);
    },
  );
}

// Slide transition from left to right (reverse transition)
Route<dynamic> slideTransitionLeftToRight(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var begin =
          const Offset(-1.0, 0.0); // Starting position: left of the screen
      var end = Offset.zero; // Ending position: the screen itself
      var curve = Curves.easeInOut; // Animation curve
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);

      return SlideTransition(position: offsetAnimation, child: child);
    },
  );
}

// Fade transition (common for screen fades)
Route<dynamic> fadeTransition(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var begin = 0.0;
      var end = 1.0;
      var curve = Curves.easeInOut;
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var opacityAnimation = animation.drive(tween);

      return FadeTransition(opacity: opacityAnimation, child: child);
    },
  );
}

// Scale transition (scales the new page from small to large)
Route<dynamic> scaleTransition(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var begin = 0.0;
      var end = 1.0;
      var curve = Curves.easeInOut;
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var scaleAnimation = animation.drive(tween);

      return ScaleTransition(scale: scaleAnimation, child: child);
    },
  );
}

// Slide transition from top to bottom
Route<dynamic> slideTransitionTopToBottom(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var begin =
          const Offset(0.0, -1.0); // Starting position: top of the screen
      var end = Offset.zero; // Ending position: the screen itself
      var curve = Curves.easeInOut;
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);

      return SlideTransition(position: offsetAnimation, child: child);
    },
  );
}

// Slide transition from bottom to top
Route<dynamic> slideTransitionBottomToTop(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var begin =
          const Offset(0.0, 1.0); // Starting position: bottom of the screen
      var end = Offset.zero; // Ending position: the screen itself
      var curve = Curves.easeInOut;
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);

      return SlideTransition(position: offsetAnimation, child: child);
    },
  );
}

// Rotate transition (rotate the new page)
Route<dynamic> rotateTransition(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var rotateTween =
          Tween(begin: 1.0, end: 0.0); // Rotation angle from 0 to 180 degrees
      var curve = Curves.easeInOut;
      var rotateAnimation =
          animation.drive(rotateTween.chain(CurveTween(curve: curve)));

      return RotationTransition(turns: rotateAnimation, child: child);
    },
  );
}

// Custom Bounce transition (bounce the new page into view)
Route<dynamic> bounceTransition(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var begin =
          const Offset(0.0, 1.0); // Starting position: bottom of the screen
      var end = Offset.zero;
      var curve = Curves.bounceOut; // Bounce effect
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);

      return SlideTransition(position: offsetAnimation, child: child);
    },
  );
}

// Zoom-in transition (child zooms in from center)
Route<dynamic> zoomInTransition(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var begin = 0.0;
      var end = 1.0;
      var curve = Curves.easeInOut;
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var scaleAnimation = animation.drive(tween);

      return ScaleTransition(scale: scaleAnimation, child: child);
    },
  );
}

// Flip transition (flip the new page like a card)
Route<dynamic> flipTransition(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var turns = Tween(begin: 0.0, end: 1.0); // Flip the page
      var curve = Curves.easeInOut;
      var flipAnimation =
          animation.drive(turns.chain(CurveTween(curve: curve)));

      return AnimatedBuilder(
        animation: flipAnimation,
        builder: (context, child) {
          var angle = flipAnimation.value * 3.1416; // Flip angle in radians
          return Transform(
            transform: Matrix4.rotationY(angle),
            alignment: Alignment.center,
            child: child,
          );
        },
        child: child,
      );
    },
  );
}

// Shrink transition (shrinks the new page from large to small)
Route<dynamic> shrinkTransition(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      var begin = 1.5;
      var end = 1.0;
      var curve = Curves.easeInOut;
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var scaleAnimation = animation.drive(tween);

      return ScaleTransition(scale: scaleAnimation, child: child);
    },
  );
}
