import 'package:flutter/material.dart';
import 'package:event_management_system/views/components/custom_button.dart';
import 'package:event_management_system/views/components/custom_text_field.dart';
import 'package:event_management_system/models/event_model.dart';
import 'package:event_management_system/services/event_service.dart';
import 'package:event_management_system/utils/constants.dart';
import 'package:event_management_system/utils/theme.dart';
import 'package:intl/intl.dart';

class EventRegistrationScreen extends StatefulWidget {
  const EventRegistrationScreen({super.key});

  @override
  _EventRegistrationScreenState createState() =>
      _EventRegistrationScreenState();
}

class _EventRegistrationScreenState extends State<EventRegistrationScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _eventNameController = TextEditingController();
  final TextEditingController _eventDescriptionController =
      TextEditingController();
  final TextEditingController _ticketQuantityController =
      TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();
  final TextEditingController _organizerNameController =
      TextEditingController();
  final TextEditingController _organizerContactController =
      TextEditingController();
  final TextEditingController _categoryController = TextEditingController();
  final TextEditingController _ticketPriceController = TextEditingController();
  final TextEditingController _imageUrlController = TextEditingController();
  final TextEditingController _contactInfoController = TextEditingController();
  final TextEditingController _registrationLinkController =
      TextEditingController();

  DateTime? _eventDate;
  TimeOfDay? _eventTime;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() {
        _eventDate = picked;
        _dateController.text = DateFormat('MMM dd, yyyy').format(_eventDate!);
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        _eventTime = picked;
        _timeController.text = _eventTime!.format(context);
      });
    }
  }

  void _submitForm() async {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();

      if (_eventDate == null || _eventTime == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please select both date and time.")),
        );
        return;
      }

      final DateTime eventDateTime = DateTime(
        _eventDate!.year,
        _eventDate!.month,
        _eventDate!.day,
        _eventTime!.hour,
        _eventTime!.minute,
      );

      final DateTime now = DateTime.now();
      if (eventDateTime.isBefore(now.subtract(const Duration(minutes: 1)))) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content:
                Text("Event date and time must be in the present or future."),
          ),
        );
        return;
      }

      final event = EventModel(
        id: UniqueKey().toString(),
        name: _eventNameController.text,
        description: _eventDescriptionController.text,
        date: eventDateTime,
        location: _locationController.text,
        totalTickets: int.tryParse(_ticketQuantityController.text) ?? 0,
        ticketsSold: 0,
        organizerName: _organizerNameController.text,
        organizerContact: _organizerContactController.text,
        category: _categoryController.text,
        ticketPrice: double.tryParse(_ticketPriceController.text) ?? 0.0,
        imageUrl: _imageUrlController.text,
        contactInfo: _contactInfoController.text,
        registrationLink: _registrationLinkController.text,
      );

      try {
        await EventService().addEvent(event);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(AppConstants.eventRegistered)),
        );
        _clearFields();
      } catch (e) {
        print('Error saving event: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Error saving event. Please try again later.')),
        );
      }
    }
  }

  void _clearFields() {
    _eventNameController.clear();
    _eventDescriptionController.clear();
    _ticketQuantityController.clear();
    _locationController.clear();
    _dateController.clear();
    _timeController.clear();
    _organizerNameController.clear();
    _organizerContactController.clear();
    _categoryController.clear();
    _ticketPriceController.clear();
    _imageUrlController.clear();
    _contactInfoController.clear();
    _registrationLinkController.clear();
    _eventDate = null;
    _eventTime = null;
  }

  // Show Category Selection Dialog
  void _showCategoryDialog() async {
    final List<String> categories = [
      'Music',
      'Art',
      'Technology',
      'Food & Drink',
      'Sports',
      'Health'
    ];

    final String? selectedCategory = await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Select Event Category"),
          content: SingleChildScrollView(
            child: ListBody(
              children: categories.map((category) {
                return GestureDetector(
                  onTap: () {
                    Navigator.of(context)
                        .pop(category); // Return selected category
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(category),
                  ),
                );
              }).toList(),
            ),
          ),
        );
      },
    );

    if (selectedCategory != null) {
      setState(() {
        _categoryController.text = selectedCategory;
      });
    }
  }

  // Show Ticket Price Selection Dialog
  void _showTicketPriceDialog() async {
    final List<String> prices = ['500', '1000', '2000', '2500', '5000', 'Free'];

    final String? selectedPrice = await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Select Ticket Price"),
          content: SingleChildScrollView(
            child: ListBody(
              children: prices.map((price) {
                return GestureDetector(
                  onTap: () {
                    Navigator.of(context).pop(price); // Return selected price
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(price),
                  ),
                );
              }).toList(),
            ),
          ),
        );
      },
    );

    if (selectedPrice != null) {
      setState(() {
        _ticketPriceController.text = selectedPrice;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.eventRegistrationTitle),
        backgroundColor: AppTheme.primaryColor,
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: constraints.maxHeight,
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomTextField(
                        controller: _eventNameController,
                        label: AppConstants.eventTitle,
                        validator: (value) => value?.isEmpty ?? true
                            ? AppConstants.emptyFieldError
                            : null,
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: _eventDescriptionController,
                        label: AppConstants.eventDescriptionLabel,
                        validator: (value) => value?.isEmpty ?? true
                            ? AppConstants.emptyFieldError
                            : null,
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: _ticketQuantityController,
                        label: AppConstants.ticketQuantityLabel,
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return AppConstants.ticketQuantityError;
                          }
                          final quantity = int.tryParse(value!);
                          return (quantity == null || quantity <= 0)
                              ? "Enter a valid number."
                              : null;
                        },
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: _locationController,
                        label: AppConstants.eventLocation,
                        validator: (value) => value?.isEmpty ?? true
                            ? AppConstants.emptyFieldError
                            : null,
                      ),
                      const SizedBox(height: 16),
                      GestureDetector(
                        onTap: () => _selectDate(context),
                        child: AbsorbPointer(
                          child: CustomTextField(
                            controller: _dateController,
                            label: AppConstants.eventDateLabel,
                            validator: (value) => value?.isEmpty ?? true
                                ? AppConstants.eventDateError
                                : null,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      GestureDetector(
                        onTap: () => _selectTime(context),
                        child: AbsorbPointer(
                          child: CustomTextField(
                            controller: _timeController,
                            label: AppConstants.eventTime,
                            validator: (value) => value?.isEmpty ?? true
                                ? AppConstants.eventDateError
                                : null,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: _organizerNameController,
                        label: AppConstants.eventOrganizerName,
                        validator: (value) => value?.isEmpty ?? true
                            ? AppConstants.emptyFieldError
                            : null,
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: _organizerContactController,
                        label: AppConstants.eventOrganizerContact,
                        validator: (value) => value?.isEmpty ?? true
                            ? AppConstants.emptyFieldError
                            : null,
                      ),
                      const SizedBox(height: 16),
                      // Category Input (GestureDetector used here)
                      GestureDetector(
                        onTap: _showCategoryDialog,
                        child: CustomTextField(
                          controller: _categoryController,
                          label: AppConstants.eventCategoryLabel,
                          validator: (value) => value?.isEmpty ?? true
                              ? AppConstants.emptyFieldError
                              : null,
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Ticket Price Input (GestureDetector used here)
                      GestureDetector(
                        onTap: _showTicketPriceDialog,
                        child: CustomTextField(
                          controller: _ticketPriceController,
                          label: AppConstants.ticketPriceLabel,
                          validator: (value) => value?.isEmpty ?? true
                              ? AppConstants.emptyFieldError
                              : null,
                        ),
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: _imageUrlController,
                        label: AppConstants.eventImageUrlLabel,
                        validator: (value) => value?.isEmpty ?? true
                            ? AppConstants.emptyFieldError
                            : null,
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: _contactInfoController,
                        label: AppConstants.contactInfoLabel,
                        validator: (value) => value?.isEmpty ?? true
                            ? AppConstants.emptyFieldError
                            : null,
                      ),
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: _registrationLinkController,
                        label: AppConstants.registrationLinkLabel,
                        validator: (value) => value?.isEmpty ?? true
                            ? AppConstants.emptyFieldError
                            : null,
                      ),
                      const SizedBox(height: 16),
                      CustomButton(
                        text: AppConstants.registerEventButtonText,
                        onPressed: _submitForm,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
