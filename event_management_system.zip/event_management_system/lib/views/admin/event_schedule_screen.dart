import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // For date formatting
import 'package:event_management_system/models/event_model.dart';
import 'package:event_management_system/services/firebase_storage_service.dart'; // Correct import
import 'package:event_management_system/utils/constants.dart';
import 'package:event_management_system/utils/theme.dart';

class EventScheduleScreen extends StatefulWidget {
  const EventScheduleScreen({super.key});

  @override
  _EventScheduleScreenState createState() => _EventScheduleScreenState();
}

class _EventScheduleScreenState extends State<EventScheduleScreen> {
  List<EventModel> _events = [];
  bool _isLoading = true;
  String? _errorMessage;

  // FirestoreService instance for fetching events from Firestore
  final FirestoreService _firebaseStorageService = FirestoreService();

  // Load events method
  Future<void> _loadEvents() async {
    try {
      // Fetch events from Firestore using FirestoreService
      final events = await _firebaseStorageService
          .getAvailableEvents(); // Fetch from 'availableEvents' collection
      setState(() {
        _events = events;
        _isLoading = false;
      });
    } catch (error) {
      setState(() {
        _errorMessage = 'Failed to load events. Please try again later.';
        _isLoading = false;
      });
    }
  }

  // Delete event function (called on delete button press)
  Future<void> _deleteEvent(String eventId) async {
    try {
      await _firebaseStorageService.deleteEvent(eventId);
      setState(() {
        _events.removeWhere((event) => event.id == eventId);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Event deleted successfully')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    _loadEvents();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.eventScheduleTitle),
        backgroundColor: AppTheme.primaryColor,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
              ? Center(
                  child: Text(
                    _errorMessage!,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.red,
                    ),
                    textAlign: TextAlign.center,
                  ),
                )
              : _events.isEmpty
                  ? const Center(
                      child: Text(
                        AppConstants.noEventsScheduled,
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _events.length,
                      itemBuilder: (context, index) {
                        final event = _events[index];
                        return Card(
                          margin: const EdgeInsets.all(10),
                          child: ListTile(
                            title: Text(
                              event.name,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              '${AppConstants.eventDateLabel}: ${DateFormat('MMM dd, yyyy').format(event.date)}',
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.delete),
                                  onPressed: () => _deleteEvent(event.id),
                                ),
                                const Icon(Icons.arrow_forward),
                              ],
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      EventDetailsScreen(event: event),
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
    );
  }
}

class EventDetailsScreen extends StatelessWidget {
  final EventModel event;

  const EventDetailsScreen({super.key, required this.event});

  // Function to delete the event
  Future<void> _deleteEvent(BuildContext context) async {
    try {
      await FirestoreService().deleteEvent(event.id);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Event deleted successfully')),
      );
      Navigator.pop(context); // Return to the previous screen after deletion
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.eventDetailsTitle),
        backgroundColor: AppTheme.primaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Event Name
            Text(
              event.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),

            // Event Description
            Text(
              '${AppConstants.eventDescriptionLabel}: ${event.description.isEmpty ? 'No description available' : event.description}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Event Location
            Text(
              '${AppConstants.eventLocation}: ${event.location.isEmpty ? 'No location available' : event.location}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Event Date
            Text(
              '${AppConstants.eventDateLabel}: ${DateFormat('MMM dd, yyyy').format(event.date)}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Event Time
            Text(
              '${AppConstants.eventTime}: ${DateFormat('hh:mm a').format(event.date)}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Organizer Name
            Text(
              '${AppConstants.eventOrganizerName}: ${event.organizerName}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Organizer Contact
            Text(
              '${AppConstants.eventOrganizerContact}: ${event.organizerContact}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Event Category
            Text(
              '${AppConstants.eventCategoryLabel}: ${event.category}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Ticket Price
            Text(
              '${AppConstants.ticketPriceLabel}: \$${event.ticketPrice.toStringAsFixed(2)}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Event Image URL
            Text(
              '${AppConstants.eventImageUrlLabel}: ${event.imageUrl.isEmpty ? 'No image available' : event.imageUrl}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Contact Info
            Text(
              '${AppConstants.contactInfoLabel}: ${event.contactInfo.isEmpty ? 'No contact info available' : event.contactInfo}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Registration Link
            Text(
              '${AppConstants.registrationLinkLabel}: ${event.registrationLink.isEmpty ? 'No registration link available' : event.registrationLink}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 30),

            // Delete Button
            ElevatedButton(
              onPressed: () => _deleteEvent(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red, // Red color for the delete button
              ),
              child: const Text(
                'Delete Event',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
