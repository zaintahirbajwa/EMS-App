import 'package:flutter/material.dart';
import 'package:event_management_system/services/chat_service.dart'; // Import ChatService
import 'package:event_management_system/services/auth_service.dart'; // Import AuthService

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> _messages = [];
  bool _isLoading = false;

  final ChatService _chatService = ChatService();
  final AuthService _authService =
      AuthService(); // Use AuthService for auth code retrieval
  String? _accessToken;

  @override
  void initState() {
    super.initState();
    _authenticate(); // Authenticate and get the access token
  }

  Future<void> _authenticate() async {
    try {
      // Retrieve the auth code dynamically from AuthService
      final authCode = await _authService.getAuthCode();

      // Use the auth code to obtain an access token
      _accessToken = await _chatService.getAccessToken(authCode!);
    } catch (e) {
      setState(() {
        _messages
            .add({'role': 'bot', 'message': 'Error during authentication: $e'});
      });
    }
  }

  Future<void> _sendMessage() async {
    String userMessage = _controller.text.trim();
    if (userMessage.isEmpty || _accessToken == null) return;

    setState(() {
      _messages.add({'role': 'user', 'message': userMessage});
      _isLoading = true; // Show loading indicator
    });

    _controller.clear();

    try {
      // Call sendMessage to get a response from the Gemini API
      final response =
          await _chatService.sendMessage(userMessage, _accessToken!);
      setState(() {
        _messages.add({'role': 'bot', 'message': response});
      });
    } catch (e) {
      setState(() {
        _messages.add({'role': 'bot', 'message': 'Error: $e'});
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Widget _buildChatMessages() {
    return ListView.builder(
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        var message = _messages[index];
        bool isUserMessage = message['role'] == 'user';
        return ListTile(
          title: Align(
            alignment:
                isUserMessage ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 18),
              decoration: BoxDecoration(
                color: isUserMessage ? Colors.blue : Colors.grey[300],
                borderRadius: BorderRadius.circular(20),
              ),
              child: SelectableText(
                message['message']!,
                style: TextStyle(
                  color: isUserMessage ? Colors.white : Colors.black,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chat with Gemini AI'),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        children: [
          Expanded(child: _buildChatMessages()),
          if (_isLoading)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: CircularProgressIndicator(),
            ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      labelText: 'Type a message',
                      filled: true,
                      fillColor: Colors.grey[100],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _sendMessage,
                  color: Colors.blue,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
