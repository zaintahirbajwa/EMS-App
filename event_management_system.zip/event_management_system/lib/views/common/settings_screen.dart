import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:event_management_system/utils/theme.dart';
import 'package:event_management_system/views/auth/login_screen.dart';
import 'package:event_management_system/utils/theme_provider.dart';
import 'package:event_management_system/utils/animations.dart'; // Import the animations

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    // Method to change language (Placeholder for future implementation)
    void changeLanguage(String? newLanguage) {
      if (newLanguage != null) {
        // Implement your language change logic here
        print('Language changed to $newLanguage');
      }
    }

    // Confirm logout dialog
    Future<void> confirmLogout() async {
      final bool? confirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Logout Confirmation'),
          content: const Text('Are you sure you want to logout?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Logout'),
            ),
          ],
        ),
      );

      if (confirm == true) {
        try {
          // Apply a fade transition while navigating to the login screen
          Navigator.pushReplacement(
            context,
            fadeTransition(const LoginScreen()),
          );
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("Logout failed. Please try again."),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }

    // Show BottomSheet for language selection
    void showLanguageBottomSheet() {
      showModalBottomSheet(
        context: context,
        builder: (context) => Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <String>[
              'English',
              'Spanish',
              'French',
              'German',
            ].map((language) {
              return ListTile(
                title: Text(language),
                onTap: () {
                  changeLanguage(language);
                  Navigator.pop(context);
                },
              );
            }).toList(),
          ),
        ),
      );
    }

    // Show BottomSheet for theme selection
    void showThemeBottomSheet() {
      showModalBottomSheet(
        context: context,
        builder: (context) => Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <String>['Light Mode', 'Dark Mode'].map((theme) {
              return ListTile(
                title: Text(theme),
                onTap: () {
                  if (theme == 'Light Mode') {
                    themeProvider.setLightMode();
                  } else {
                    themeProvider.setDarkMode();
                  }
                  Navigator.pop(context);
                },
              );
            }).toList(),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: AppTheme.primaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Language selection button
            ElevatedButton(
              onPressed: showLanguageBottomSheet,
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    themeProvider.isDarkMode ? Colors.grey[900] : Colors.white,
                padding:
                    const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: AppTheme.primaryColor),
                ),
                elevation: 0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Select Language',
                    style: TextStyle(
                      fontSize: 16,
                      color: themeProvider.isDarkMode
                          ? Colors.white
                          : AppTheme.primaryColor,
                    ),
                  ),
                  Icon(
                    Icons.arrow_drop_down,
                    color: themeProvider.isDarkMode
                        ? Colors.white
                        : AppTheme.primaryColor,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // App Appearance button
            ElevatedButton(
              onPressed: showThemeBottomSheet,
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    themeProvider.isDarkMode ? Colors.grey[900] : Colors.white,
                padding:
                    const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: AppTheme.primaryColor),
                ),
                elevation: 0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'App Appearance',
                    style: TextStyle(
                      fontSize: 16,
                      color: themeProvider.isDarkMode
                          ? Colors.white
                          : AppTheme.primaryColor,
                    ),
                  ),
                  Icon(
                    Icons.arrow_drop_down,
                    color: themeProvider.isDarkMode
                        ? Colors.white
                        : AppTheme.primaryColor,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Logout Button with bounce animation
            ElevatedButton(
              onPressed: confirmLogout,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 4,
              ),
              child: const Text(
                'Logout',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
