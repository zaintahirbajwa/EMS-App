import 'package:flutter/material.dart';
import 'package:event_management_system/models/event_model.dart';
import 'package:event_management_system/utils/constants.dart';
import 'package:event_management_system/utils/theme.dart';
import 'package:event_management_system/services/auth_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class UserScheduleScreen extends StatefulWidget {
  const UserScheduleScreen({super.key});

  @override
  _UserScheduleScreenState createState() => _UserScheduleScreenState();
}

class _UserScheduleScreenState extends State<UserScheduleScreen> {
  List<EventModel> _userEvents = [];
  final AuthService _authService = AuthService();
  bool _isLoading = true;
  String? _errorMessage;

  // Fetch events that the user has tickets for from Firestore
  Future<void> _loadUserEvents() async {
    // Get the current user's ID
    String? userId = await _authService.getCurrentUserId();

    if (userId == null || userId.isEmpty) {
      // Handle case when user is not logged in or no user ID is available
      setState(() {
        _errorMessage = 'User not logged in';
        _isLoading = false;
      });
      return;
    }

    try {
      // Fetch the user's ticket purchases from Firestore (assuming you have a collection to track user tickets)
      QuerySnapshot userTicketsSnapshot = await FirebaseFirestore.instance
          .collection('userTickets')
          .where('userId', isEqualTo: userId)
          .get();

      // Debugging - print the fetched ticket records
      print("User Tickets Snapshot: ${userTicketsSnapshot.docs}");

      // Extract event IDs from the user's ticket records
      List<String> eventIds = userTicketsSnapshot.docs
          .map((doc) => doc['eventId'] as String)
          .toList();

      // Debugging - print the event IDs
      print("Event IDs: $eventIds");

      if (eventIds.isEmpty) {
        setState(() {
          _userEvents = [];
          _isLoading = false;
        });
        return;
      }

      // Remove duplicate event IDs
      eventIds = eventIds.toSet().toList();
      print("Event IDs after removing duplicates: $eventIds");

      // Fetch the events corresponding to the ticketed events
      List<EventModel> events = [];
      for (var i = 0; i < eventIds.length; i += 10) {
        // Handle batching for whereIn query, Firestore limit is 10
        var batch = eventIds.sublist(
            i, i + 10 > eventIds.length ? eventIds.length : i + 10);
        QuerySnapshot eventsSnapshot = await FirebaseFirestore.instance
            .collection('events')
            .where(FieldPath.documentId, whereIn: batch)
            .get();

        // Map the fetched documents to EventModel instances
        events.addAll(eventsSnapshot.docs.map((doc) {
          var data = doc.data() as Map<String, dynamic>;
          return EventModel(
            id: doc.id,
            name: data['name'] ?? '',
            description: data['description'] ?? '',
            date: (data['date'] as Timestamp).toDate(),
            location: data['location'] ?? '',
            totalTickets: data['totalTickets'] ?? 0,
            ticketsSold: data['ticketsSold'] ?? 0,
            organizerName: data['organizerName'] ?? '',
            organizerContact: data['organizerContact'] ?? '',
            category: data['category'] ?? '',
            ticketPrice: data['ticketPrice']?.toDouble() ?? 0.0,
            imageUrl: data['imageUrl'] ?? '',
            contactInfo: data['contactInfo'] ?? '',
            registrationLink: data['registrationLink'] ?? '',
          );
        }).toList());
      }

      setState(() {
        _userEvents = events;
        _isLoading = false;
      });
    } catch (error) {
      setState(() {
        _errorMessage = 'Failed to load events. Please try again later.';
        _isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _loadUserEvents();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.userScheduleTitle),
        backgroundColor: AppTheme.primaryColor, // Apply theme primary color
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
              ? Center(
                  child: Text(
                    _errorMessage!,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.red,
                    ),
                    textAlign: TextAlign.center,
                  ),
                )
              : _userEvents.isEmpty
                  ? Center(
                      child: Text(
                        AppConstants.noTicketsBooked,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context)
                              .textTheme
                              .bodyLarge
                              ?.color, // Use theme text color
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _userEvents.length,
                      itemBuilder: (context, index) {
                        final event = _userEvents[index];
                        return Card(
                          margin: const EdgeInsets.all(10),
                          color: Theme.of(context)
                              .cardColor, // Use theme card color
                          child: ListTile(
                            title: Text(
                              event.name,
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context)
                                    .textTheme
                                    .titleLarge
                                    ?.color, // Use theme for text color
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${AppConstants.eventDateLabel}: ${event.date.toLocal()}'
                                      .split(' ')[0],
                                  style: TextStyle(
                                    color: Theme.of(context)
                                        .textTheme
                                        .bodyLarge
                                        ?.color, // Theme-based text color
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  'Organizer: ${event.organizerName}',
                                  style: TextStyle(
                                    fontStyle: FontStyle.italic,
                                    color: Theme.of(context)
                                        .textTheme
                                        .bodyMedium
                                        ?.color, // Theme-based text color
                                  ),
                                ),
                                Text(
                                  'Contact: ${event.organizerContact}',
                                  style: TextStyle(
                                    fontStyle: FontStyle.italic,
                                    color: Theme.of(context)
                                        .textTheme
                                        .bodyMedium
                                        ?.color, // Theme-based text color
                                  ),
                                ),
                              ],
                            ),
                            trailing: Text(
                              '${AppConstants.ticketPriceLabel}: \$${event.ticketPrice.toStringAsFixed(2)}',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context)
                                    .textTheme
                                    .bodyLarge
                                    ?.color, // Theme-based text color
                              ),
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}
